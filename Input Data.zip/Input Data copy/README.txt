This dataset consists of three files:

"1951_2014_all_vars_mgd.txt"
"SILO_83010.txt"
"SILO_-365514670.txt"

--------------
"1951_2014_all_vars_mgd.txt"
--------------
Data accessed from the National Computational Infrastructure (NCI),

reference: https://doi.org/10.25914/ysxb-rt43

ACCESS-ESM1-5, physics scheme R5, experiment r6i1p1f1 (historical)

Daily data from 1951-2014 extracted at 146.72 deg E, 36.571 deg S, being the
streamflow gauge location of catchment 403210, Ovens River @ Myrtleford.

(Most) variable names and units are given in:
https://is-enes-data.github.io/CORDEX_variables_requirement_table.pdf

The target variable (rainfall/precipitation) is "pr", which is given in units
of kg.m^{-2}.s^{-1} (to convert to mm/day, multiply by 86400).

Some variables may not appear in the CORDEX variables list, in particular the
upper case variables (e.g. CAPE) which looks like it is a WRF (RCM) internal
variable, rather than a GCM variable.

Data was extracted via CDO remapnn function (nearest-neighbour mapping):
https://code.mpimet.mpg.de/projects/cdo/embedded/index.html
section 2.12.3

--------------
"SILO_83010.txt"
--------------

Patched point data (PPD), i.e. infilled data for rainfall station
830210 EUROBIN, 
Lat: -36.6344 Long:  146.8628
being closest climate station to the gauge location for catchment 403210.csv
"   Further information is available from http://www.longpaddock.qld.gov.au/silo"

--------------
"SILO_-365514670.txt"
--------------

Interpolated rainfall data for grid cell
Lat: -36.55, Long: 146.70

--------------



Nick Potter & Jin Teng, 3 October 2024
